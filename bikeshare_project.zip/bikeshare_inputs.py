def city_input():
    print('Invalid Entry')
    city = input('Enter City:').lower()
    return city

def month_input():
    print('Invalid Entry')
    month = input('Enter Month:').lower()
    return month

def day_input():
    print('Invalid Entry')
    day = input('Enter Day:').lower()
    return day
